#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from pyelectrica.pyelectrica import *
import pyelectrica.pyelectrica
__doc__ = pyelectrica.pyelectrica.__doc__


name =  "pyelectrica"
